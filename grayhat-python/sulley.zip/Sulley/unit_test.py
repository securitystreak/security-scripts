#!c:\\python\\python.exe

import unit_tests

unit_tests.blocks.run()
unit_tests.legos.run()
unit_tests.primitives.run()